-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 24, 2019 at 11:04 AM
-- Server version: 5.5.61-cll
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `omcropsc_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `actualslaentry`
--

CREATE TABLE `actualslaentry` (
  `actSaleID` int(11) NOT NULL,
  `actSaleQty` varchar(255) NOT NULL,
  `actSaleRate` decimal(10,2) NOT NULL,
  `actSaleDC` decimal(10,2) NOT NULL,
  `actSaleAmount` double(10,2) NOT NULL,
  `actSaleDate` date NOT NULL,
  `actSaleNurth` text NOT NULL,
  `actCompanyID` int(11) NOT NULL,
  `actDelarID` int(11) NOT NULL,
  `actAdminUserId` int(11) NOT NULL,
  `actVirSalIntmentID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `actualslaentry`
--

INSERT INTO `actualslaentry` (`actSaleID`, `actSaleQty`, `actSaleRate`, `actSaleDC`, `actSaleAmount`, `actSaleDate`, `actSaleNurth`, `actCompanyID`, `actDelarID`, `actAdminUserId`, `actVirSalIntmentID`) VALUES
(7, '10.010', '33125.00', '900.00', 500000.00, '2004-09-24', '34025.00, 900.00, 0, 34025.00, 900.00, 0, 0, 0, 1, 33125, 10.010, 500000, 500000, 500000, 0', 2, 10, 5, 30),
(8, '10.090', '33125.00', '400.00', 500000.00, '2004-09-24', '34025.00, 900.00, 0, 34025.00, 400.00, 0, 0, 0, 2, 33125, 10.090, 500000, 500000, 505045, 5045', 2, 11, 5, 31),
(9, '12.200', '33325.00', '900.00', 600000.00, '2004-09-24', '34225.00, 900.00, 0, 34225, 900, 0, 0, 0, 3, 33325, 12.200, 600000, 600000, 600000, 0', 2, 0, 5, 0),
(10, '10', '34025.00', '400.00', 0.00, '2004-09-24', '', 2, 10, 5, 0),
(11, '10', '1000.00', '400.00', 100.00, '2004-09-24', '38500.00, 700.00, 38500.00, 400.00, 380000, 383000, 0, 3000, 300', 14, 11, 5, 32);

-- --------------------------------------------------------

--
-- Table structure for table `adminLogin`
--

CREATE TABLE `adminLogin` (
  `adminID` int(11) NOT NULL,
  `admLoginID` varchar(20) NOT NULL,
  `admloginPass` varchar(20) NOT NULL,
  `admName` varchar(25) NOT NULL,
  `admStatus` enum('Active','Inactive') NOT NULL,
  `admAccType` enum('Admin','Employee','Super Admin') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminLogin`
--

INSERT INTO `adminLogin` (`adminID`, `admLoginID`, `admloginPass`, `admName`, `admStatus`, `admAccType`) VALUES
(1, 'superadmin@gmail.com', '123', 'Head', 'Active', 'Super Admin'),
(2, 'admin@gmail.com', '123', 'Admin', 'Active', 'Admin'),
(3, 'employee@gmail.com', '123', 'Employee', 'Active', 'Employee'),
(4, 'abc@gmail.com', 'abcd', 'Test', 'Active', 'Employee'),
(5, 'testing@gmail.com', '123', 'Rohan', 'Active', 'Employee');

-- --------------------------------------------------------

--
-- Table structure for table `cash_entry_master`
--

CREATE TABLE `cash_entry_master` (
  `cash_entry_id` int(11) NOT NULL,
  `payment_byto_id` int(11) NOT NULL,
  `payment_to_id` int(11) NOT NULL,
  `cash_amount` double(10,2) NOT NULL,
  `cash_entry_date` date NOT NULL,
  `cash_narration` text NOT NULL,
  `login_user_id` int(11) NOT NULL,
  `payment_status` enum('0','1','2','3','4') NOT NULL COMMENT '0=receiptpayment,1=receipt,2=payment,3=purchase,4=sale'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cash_entry_master`
--

INSERT INTO `cash_entry_master` (`cash_entry_id`, `payment_byto_id`, `payment_to_id`, `cash_amount`, `cash_entry_date`, `cash_narration`, `login_user_id`, `payment_status`) VALUES
(5, 2, 0, 398343.00, '2019-09-11', '34425.00, 900.00, 34425.00, 0.00, 398343, 407451, 700, 0, 900', 2, '3'),
(6, 11, 0, 407451.00, '2019-09-11', '34425.00, 900.00, 34425.00, 0.00, 398343, 407451, 700, 0, 900', 2, '4'),
(7, 2, 0, 365075.00, '2019-09-11', '34725.00, 900.00, 34725.00, 900.00, 365075, 365075, 450, 0, 0', 2, '3'),
(8, 10, 0, 365075.00, '2019-09-11', '34725.00, 900.00, 34725.00, 900.00, 365075, 365075, 450, 0, 0', 2, '4'),
(9, 2, 0, 387345.00, '2019-09-11', '34925.00, 400.00, 34925, 400.00, 387345, 387345, 400, 0, 0', 2, '3'),
(10, 0, 0, 387345.00, '2019-09-11', '34925.00, 400.00, 34925, 400.00, 387345, 387345, 400, 0, 0', 2, '4'),
(15, 2, 0, 500000.00, '2004-09-24', '34025.00, 900.00, 0, 34025.00, 900.00, 0, 0, 0, 1, 33125, 10.010, 500000, 500000, 500000, 0', 5, '3'),
(16, 10, 0, 500000.00, '2004-09-24', '34025.00, 900.00, 0, 0, 0, 10.010', 5, '4'),
(17, 2, 0, 500000.00, '2004-09-24', '34025.00, 900.00, 0, 34025.00, 400.00, 0, 0, 0, 2, 33125, 10.090, 500000, 500000, 505045, 5045', 5, '3'),
(18, 11, 0, 505045.00, '2004-09-24', '34025.00, 400.00, 0, 0, 0, 10.090', 5, '4'),
(19, 2, 0, 600000.00, '2004-09-24', '34225.00, 900.00, 0, 34225, 900, 0, 0, 0, 3, 33325, 12.200, 600000, 600000, 600000, 0', 5, '3'),
(20, 0, 0, 600000.00, '2004-09-24', '34225, 900, 0, 0, 0, 12.200', 5, '4'),
(21, 10, 0, 20000.00, '2019-09-24', 'B1 (Broker, INDORE)', 5, '1'),
(22, 1, 11, 300000.00, '2019-09-24', 'B2 (Broker, RATLAM), J (Company, )', 5, '0'),
(23, 14, 0, 380001.00, '2004-09-24', '38500.00, 700.00, 38500.00, 400.00, 380000, 383000, 0, 3000, 300', 5, '3'),
(24, 11, 0, 383001.00, '2004-09-24', '38500.00, 700.00, 38500.00, 400.00, 380000, 383000, 0, 3000, 300', 5, '4');

-- --------------------------------------------------------

--
-- Table structure for table `excel_report`
--

CREATE TABLE `excel_report` (
  `report_id` int(11) NOT NULL,
  `report_desc` text NOT NULL,
  `admin_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `excel_report`
--

INSERT INTO `excel_report` (`report_id`, `report_desc`, `admin_id`) VALUES
(2, '{\"excelPartyName\":\"d\",\"excelDate\":\"2019-09-09\",\"excelFatemi\":\"lk\",\"excelNonData\":\"10\",\"excelDiff\":\"10\",\"excelCD\":\"10\",\"excelFRT\":\"10\",\"excelNDCFTotal\":\"0\",\"excelPlusDCFTotalettmm\":\"10001000\",\"excelPlusDCFTotalttfmm\":\"0\",\"excelTaxtttfenp\":\"0\",\"excelTaxetttenp\":\"180\",\"excelRateetttmm\":\"1180\",\"excelRatetttfmm\":\"0\",\"excelQtyeightmm\":\"10\",\"excelQtytenmm\":\"10\",\"excelQtytwielmm\":\"10\",\"excelQtysixteenmm\":\"10\",\"excelQtytwintymm\":\"10\",\"excelQtytwintyfivemm\":\"10\",\"excelQtythirtytwomm\":\"10\",\"excelTotalQty\":\"70\",\"excelInclude1\":\"1180\",\"excelInclude2\":\"0\",\"excelInclude3\":\"0\",\"excelInclude4\":\"0\",\"excelInclude5\":\"0\",\"excelInclude6\":\"0\",\"excelInclude7\":\"1180\",\"excelAmount1\":\"11.80\",\"excelAmount2\":\"0.00\",\"excelAmount3\":\"0.00\",\"excelAmount4\":\"0.00\",\"excelAmount5\":\"0.00\",\"excelAmount6\":\"0.00\",\"excelAmount7\":\"11.80\",\"excelTotalAmount\":\"23.60\",\"excelDalali\":\"10\",\"excelDalaliTotal\":\"0.7\",\"excelDiffFormula\":\"-10\",\"excelDiffTotal\":\"-0.7\",\"excelRateDiff\":\"10\",\"excelRateDiffTotal\":\"0.7\",\"excelRateDiffQty\":\"10\",\"excelRateDiffQtyTotal\":\"0.7\",\"excelTotalRF\":\"100\",\"excelTotalCalculationAmount\":\"12500.00\"}', 2),
(3, '{\"excelPartyName\":\"d\",\"excelDate\":\"2019-09-10\",\"excelFatemi\":\"lk\",\"excelNonData\":\"10\",\"excelDiff\":\"10\",\"excelCD\":\"10\",\"excelFRT\":\"10\",\"excelNDCFTotal\":\"0\",\"excelPlusDCFTotalettmm\":\"1000\",\"excelPlusDCFTotalttfmm\":\"0\",\"excelTaxtttfenp\":\"0\",\"excelTaxetttenp\":\"180\",\"excelRateetttmm\":\"1180\",\"excelRatetttfmm\":\"0\",\"excelQtyeightmm\":\"10\",\"excelQtytenmm\":\"10\",\"excelQtytwielmm\":\"10\",\"excelQtysixteenmm\":\"10\",\"excelQtytwintymm\":\"10\",\"excelQtytwintyfivemm\":\"10\",\"excelQtythirtytwomm\":\"10\",\"excelTotalQty\":\"70\",\"excelInclude1\":\"1180\",\"excelInclude2\":\"0\",\"excelInclude3\":\"0\",\"excelInclude4\":\"0\",\"excelInclude5\":\"0\",\"excelInclude6\":\"0\",\"excelInclude7\":\"1180\",\"excelAmount1\":\"11.80\",\"excelAmount2\":\"0.00\",\"excelAmount3\":\"0.00\",\"excelAmount4\":\"0.00\",\"excelAmount5\":\"0.00\",\"excelAmount6\":\"0.00\",\"excelAmount7\":\"11.80\",\"excelTotalAmount\":\"23.60\",\"excelDalali\":\"10\",\"excelDalaliTotal\":\"0.7\",\"excelDiffFormula\":\"-10\",\"excelDiffTotal\":\"-0.7\",\"excelRateDiff\":\"10\",\"excelRateDiffTotal\":\"0.7\",\"excelRateDiffQty\":\"10\",\"excelRateDiffQtyTotal\":\"0.7\",\"excelTotalRF\":\"1000\",\"excelTotalCalculationAmount\":\"1025.00\"}', 2),
(4, '{\"excelPartyName\":\"d\",\"excelDate\":\"2019-09-10\",\"excelFatemi\":\"lk\",\"excelNonData\":\"10\",\"excelDiff\":\"10\",\"excelCD\":\"10\",\"excelFRT\":\"10\",\"excelNDCFTotal\":\"0\",\"excelPlusDCFTotalettmm\":\"1000\",\"excelPlusDCFTotalttfmm\":\"0\",\"excelTaxtttfenp\":\"0\",\"excelTaxetttenp\":\"180\",\"excelRateetttmm\":\"1180\",\"excelRatetttfmm\":\"0\",\"excelQtyeightmm\":\"10\",\"excelQtytenmm\":\"10\",\"excelQtytwielmm\":\"10\",\"excelQtysixteenmm\":\"10\",\"excelQtytwintymm\":\"10\",\"excelQtytwintyfivemm\":\"10\",\"excelQtythirtytwomm\":\"10\",\"excelTotalQty\":\"70\",\"excelInclude1\":\"1180\",\"excelInclude2\":\"0\",\"excelInclude3\":\"0\",\"excelInclude4\":\"0\",\"excelInclude5\":\"0\",\"excelInclude6\":\"0\",\"excelInclude7\":\"1180\",\"excelAmount1\":\"11.80\",\"excelAmount2\":\"0.00\",\"excelAmount3\":\"0.00\",\"excelAmount4\":\"0.00\",\"excelAmount5\":\"0.00\",\"excelAmount6\":\"0.00\",\"excelAmount7\":\"11.80\",\"excelTotalAmount\":\"23.60\",\"excelDalali\":\"10\",\"excelDalaliTotal\":\"0.7\",\"excelDiffFormula\":\"-10\",\"excelDiffTotal\":\"-0.7\",\"excelRateDiff\":\"10\",\"excelRateDiffTotal\":\"0.7\",\"excelRateDiffQty\":\"10\",\"excelRateDiffQtyTotal\":\"0.7\",\"excelTotalRF\":\"1000\",\"excelTotalCalculationAmount\":\"1025.00\"}', 2),
(5, '{\"excelPartyName\":\"d\",\"excelDate\":\"2019-09-10\",\"excelFatemi\":\"lk\",\"excelNonData\":\"10\",\"excelDiff\":\"10\",\"excelCD\":\"10\",\"excelFRT\":\"10\",\"excelNDCFTotal\":\"0\",\"excelPlusDCFTotalettmm\":\"1000\",\"excelPlusDCFTotalttfmm\":\"0\",\"excelTaxtttfenp\":\"0\",\"excelTaxetttenp\":\"180\",\"excelRateetttmm\":\"1180\",\"excelRatetttfmm\":\"0\",\"excelQtyeightmm\":\"10\",\"excelQtytenmm\":\"10\",\"excelQtytwielmm\":\"10\",\"excelQtysixteenmm\":\"10\",\"excelQtytwintymm\":\"10\",\"excelQtytwintyfivemm\":\"10\",\"excelQtythirtytwomm\":\"10\",\"excelTotalQty\":\"70\",\"excelInclude1\":\"1180\",\"excelInclude2\":\"0\",\"excelInclude3\":\"0\",\"excelInclude4\":\"0\",\"excelInclude5\":\"0\",\"excelInclude6\":\"0\",\"excelInclude7\":\"1180\",\"excelAmount1\":\"11.80\",\"excelAmount2\":\"0.00\",\"excelAmount3\":\"0.00\",\"excelAmount4\":\"0.00\",\"excelAmount5\":\"0.00\",\"excelAmount6\":\"0.00\",\"excelAmount7\":\"11.80\",\"excelTotalAmount\":\"23.60\",\"excelDalali\":\"10\",\"excelDalaliTotal\":\"0.7\",\"excelDiffFormula\":\"-10\",\"excelDiffTotal\":\"-0.7\",\"excelRateDiff\":\"10\",\"excelRateDiffTotal\":\"0.7\",\"excelRateDiffQty\":\"10\",\"excelRateDiffQtyTotal\":\"0.7\",\"excelTotalRF\":\"1000\",\"excelTotalCalculationAmount\":\"1025.00\"}', 2),
(6, '{\"excelPartyName\":\"jhkjkjh\",\"excelDate\":\"2019-09-17\",\"excelFatemi\":\"hghg\",\"excelNonData\":\"20\",\"excelDiff\":\"201\",\"excelCD\":\"20\",\"excelFRT\":\"20\",\"excelNDCFTotal\":\"181\",\"excelPlusDCFTotalettmm\":\"1181\",\"excelPlusDCFTotalttfmm\":\"181\",\"excelTaxtttfenp\":\"32.58\",\"excelTaxetttenp\":\"212.58\",\"excelRateetttmm\":\"1393.58\",\"excelRatetttfmm\":\"213.57\",\"excelQtyeightmm\":\"10\",\"excelQtytenmm\":\"10\",\"excelQtytwielmm\":\"10\",\"excelQtysixteenmm\":\"10\",\"excelQtytwintymm\":\"10\",\"excelQtytwintyfivemm\":\"10\",\"excelQtythirtytwomm\":\"10\",\"excelTotalQty\":\"70\",\"excelInclude1\":\"1393.58\",\"excelInclude2\":\"213.57\",\"excelInclude3\":\"213.57\",\"excelInclude4\":\"213.57\",\"excelInclude5\":\"213.57\",\"excelInclude6\":\"213.57\",\"excelInclude7\":\"1393.58\",\"excelAmount1\":\"13.94\",\"excelAmount2\":\"2.14\",\"excelAmount3\":\"2.14\",\"excelAmount4\":\"2.14\",\"excelAmount5\":\"2.14\",\"excelAmount6\":\"2.14\",\"excelAmount7\":\"13.94\",\"excelTotalAmount\":\"38.58\",\"excelDalali\":\"10\",\"excelDalaliTotal\":\"0.7\",\"excelDiffFormula\":\"-201\",\"excelDiffTotal\":\"-14.07\",\"excelRateDiff\":\"10\",\"excelRateDiffTotal\":\"0.7\",\"excelRateDiffQty\":\"10\",\"excelRateDiffQtyTotal\":\"0.7\",\"excelTotalRF\":\"100\",\"excelTotalCalculationAmount\":\"126.61\"}', 2),
(7, '{\"excelPartyName\":\"\",\"excelDate\":\"\",\"excelFatemi\":\"\",\"excelNonData\":\"100\",\"excelDiff\":\"100\",\"excelCD\":\"100\",\"excelFRT\":\"100\",\"excelNDCFTotal\":\"0\",\"excelPlusDCFTotalettmm\":\"1000\",\"excelPlusDCFTotalttfmm\":\"0\",\"excelTaxtttfenp\":\"0\",\"excelTaxetttenp\":\"180\",\"excelRateetttmm\":\"1180.00\",\"excelRatetttfmm\":\"0.00\",\"excelQtyeightmm\":\"121\",\"excelQtytenmm\":\"12\",\"excelQtytwielmm\":\"12\",\"excelQtysixteenmm\":\"12\",\"excelQtytwintymm\":\"121\",\"excelQtytwintyfivemm\":\"22121\",\"excelQtythirtytwomm\":\"1\",\"excelTotalQty\":\"22400\",\"excelInclude1\":\"1180.00\",\"excelInclude2\":\"0.00\",\"excelInclude3\":\"0.00\",\"excelInclude4\":\"0.00\",\"excelInclude5\":\"0.00\",\"excelInclude6\":\"0.00\",\"excelInclude7\":\"1180.00\",\"excelAmount1\":\"142.78\",\"excelAmount2\":\"0.00\",\"excelAmount3\":\"0.00\",\"excelAmount4\":\"0.00\",\"excelAmount5\":\"0.00\",\"excelAmount6\":\"0.00\",\"excelAmount7\":\"1.18\",\"excelTotalAmount\":\"143.96\",\"excelDalali\":\"1212\",\"excelDalaliTotal\":\"27148.8\",\"excelDiffFormula\":\"-100\",\"excelDiffTotal\":\"-2240\",\"excelRateDiff\":\"122\",\"excelRateDiffTotal\":\"2732.8\",\"excelRateDiffQty\":\"212\",\"excelRateDiffQtyTotal\":\"4748.8\",\"excelTotalRF\":\"212\",\"excelTotalCalculationAmount\":\"32746.36\"}', 2),
(8, '{\"excelPartyName\":\"YASH JAIN\",\"excelDate\":\"2004-09-24\",\"excelFatemi\":\"JHAVERI INFRA\",\"excelNonData\":\"34025\",\"excelDiff\":\"-150\",\"excelCD\":\"400\",\"excelFRT\":\"\",\"excelNDCFTotal\":\"33475\",\"excelPlusDCFTotalettmm\":\"34475\",\"excelPlusDCFTotalttfmm\":\"33475\",\"excelTaxtttfenp\":\"6025.5\",\"excelTaxetttenp\":\"6205.5\",\"excelRateetttmm\":\"40680.50\",\"excelRatetttfmm\":\"39500.50\",\"excelQtyeightmm\":\"3070\",\"excelQtytenmm\":\"1530\",\"excelQtytwielmm\":\"1020\",\"excelQtysixteenmm\":\"3890\",\"excelQtytwintymm\":\"460\",\"excelQtytwintyfivemm\":\"\",\"excelQtythirtytwomm\":\"\",\"excelTotalQty\":\"9970\",\"excelInclude1\":\"40680.50\",\"excelInclude2\":\"39500.50\",\"excelInclude3\":\"39500.50\",\"excelInclude4\":\"39500.50\",\"excelInclude5\":\"39500.50\",\"excelInclude6\":\"39500.50\",\"excelInclude7\":\"40680.50\",\"excelAmount1\":\"124889.13\",\"excelAmount2\":\"60435.76\",\"excelAmount3\":\"40290.51\",\"excelAmount4\":\"153656.95\",\"excelAmount5\":\"18170.23\",\"excelAmount6\":\"0.00\",\"excelAmount7\":\"0.00\",\"excelTotalAmount\":\"397442.58\",\"excelDalali\":\"\",\"excelDalaliTotal\":\"\",\"excelDiffFormula\":\"150\",\"excelDiffTotal\":\"1495.5\",\"excelRateDiff\":\"\",\"excelRateDiffTotal\":\"\",\"excelRateDiffQty\":\"\",\"excelRateDiffQtyTotal\":\"\",\"excelTotalRF\":\"\",\"excelTotalCalculationAmount\":\"398938.08\"}', 5);

-- --------------------------------------------------------

--
-- Table structure for table `openingamount`
--

CREATE TABLE `openingamount` (
  `amountID` int(11) NOT NULL,
  `inHandAmount` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `purchaseSaleEntryMaster`
--

CREATE TABLE `purchaseSaleEntryMaster` (
  `purSaleID` int(11) NOT NULL,
  `purSaleQty` varchar(50) NOT NULL,
  `purSaleRate` decimal(10,2) NOT NULL,
  `purSaleCD` decimal(10,2) NOT NULL,
  `purSaleDate` date NOT NULL,
  `purSaleNartn` text NOT NULL,
  `companyID` int(11) NOT NULL,
  `purSaleFromTo` int(11) NOT NULL,
  `purSaleType` enum('Purchase','Sale') NOT NULL,
  `purSaleadmUseId` int(11) NOT NULL,
  `purSaleTrasactionClase` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchaseSaleEntryMaster`
--

INSERT INTO `purchaseSaleEntryMaster` (`purSaleID`, `purSaleQty`, `purSaleRate`, `purSaleCD`, `purSaleDate`, `purSaleNartn`, `companyID`, `purSaleFromTo`, `purSaleType`, `purSaleadmUseId`, `purSaleTrasactionClase`) VALUES
(26, '100', '34025.00', '900.00', '2004-09-24', '', 0, 2, 'Purchase', 5, 0),
(27, '100', '38500.00', '700.00', '2004-09-24', '', 0, 14, 'Purchase', 5, 0),
(30, '20', '34025.00', '900.00', '2004-09-24', '', 2, 10, 'Sale', 5, 0),
(31, '30', '34025.00', '400.00', '2004-09-24', '', 2, 11, 'Sale', 5, 0),
(32, '20', '38500.00', '400.00', '2004-09-24', '', 14, 11, 'Sale', 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `vendorAssociateRegistration`
--

CREATE TABLE `vendorAssociateRegistration` (
  `vendAssocRegID` int(11) NOT NULL,
  `vendAssocRegName` varchar(50) NOT NULL,
  `vendAssocRegCity` varchar(50) DEFAULT NULL,
  `vendAssocRegType` enum('Company','Broker','Party') NOT NULL,
  `calculation_status` int(11) DEFAULT NULL COMMENT '0=m,1=shv'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendorAssociateRegistration`
--

INSERT INTO `vendorAssociateRegistration` (`vendAssocRegID`, `vendAssocRegName`, `vendAssocRegCity`, `vendAssocRegType`, `calculation_status`) VALUES
(1, 'J', NULL, 'Company', 0),
(2, 'J24', NULL, 'Company', 0),
(14, 'ANT', NULL, 'Company', 1),
(13, 'SHV', NULL, 'Company', 1),
(10, 'B1', 'INDORE', 'Broker', NULL),
(9, 'A1', 'MHOW', 'Party', NULL),
(11, 'B2', 'RATLAM', 'Broker', NULL),
(12, 'B3', 'Idr', 'Broker', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actualslaentry`
--
ALTER TABLE `actualslaentry`
  ADD PRIMARY KEY (`actSaleID`);

--
-- Indexes for table `adminLogin`
--
ALTER TABLE `adminLogin`
  ADD PRIMARY KEY (`adminID`),
  ADD KEY `admLoginID` (`admLoginID`),
  ADD KEY `admloginPass` (`admloginPass`);

--
-- Indexes for table `cash_entry_master`
--
ALTER TABLE `cash_entry_master`
  ADD PRIMARY KEY (`cash_entry_id`);

--
-- Indexes for table `excel_report`
--
ALTER TABLE `excel_report`
  ADD PRIMARY KEY (`report_id`);

--
-- Indexes for table `openingamount`
--
ALTER TABLE `openingamount`
  ADD PRIMARY KEY (`amountID`);

--
-- Indexes for table `purchaseSaleEntryMaster`
--
ALTER TABLE `purchaseSaleEntryMaster`
  ADD PRIMARY KEY (`purSaleID`);

--
-- Indexes for table `vendorAssociateRegistration`
--
ALTER TABLE `vendorAssociateRegistration`
  ADD PRIMARY KEY (`vendAssocRegID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actualslaentry`
--
ALTER TABLE `actualslaentry`
  MODIFY `actSaleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `adminLogin`
--
ALTER TABLE `adminLogin`
  MODIFY `adminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cash_entry_master`
--
ALTER TABLE `cash_entry_master`
  MODIFY `cash_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `excel_report`
--
ALTER TABLE `excel_report`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `openingamount`
--
ALTER TABLE `openingamount`
  MODIFY `amountID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `purchaseSaleEntryMaster`
--
ALTER TABLE `purchaseSaleEntryMaster`
  MODIFY `purSaleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `vendorAssociateRegistration`
--
ALTER TABLE `vendorAssociateRegistration`
  MODIFY `vendAssocRegID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
